
let count=0;
function add(){
 document.getElementById("counter").innerHTML=count;
 count++
}